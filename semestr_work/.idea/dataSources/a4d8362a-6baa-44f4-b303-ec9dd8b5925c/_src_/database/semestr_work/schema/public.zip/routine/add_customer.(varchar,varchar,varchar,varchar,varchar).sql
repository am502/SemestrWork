CREATE FUNCTION add_customer (ulogin character varying, upassword character varying, ufirst_name character varying, ulast_name character varying, cphone_number character varying) RETURNS void
	LANGUAGE plpgsql
AS $$
DECLARE
  uid INT;
BEGIN
  INSERT INTO users (login, password, first_name, last_name)
  VALUES (ulogin, upassword, ufirst_name, ulast_name)
  RETURNING user_id INTO uid;
  INSERT INTO customers (user_id, phone_number)
  VALUES (uid, cphone_number);
END;
$$
