CREATE FUNCTION update_delete () RETURNS trigger
	LANGUAGE plpgsql
AS $$
BEGIN
  UPDATE customers SET (status, phone_number) = ('DELETED', '') WHERE user_id IS NULL;
  UPDATE vendors SET (status, phone_number) = ('DELETED', '') WHERE user_id IS NULL;
  DELETE FROM customer_deals cd USING customers c WHERE cd.customer_id = c.customer_id AND c.user_id IS NULL;
  DELETE FROM vendor_deals vd USING vendors v WHERE vd.vendor_id = v.vendor_id AND v.user_id IS NULL;
  RETURN NULL;
END;
$$
