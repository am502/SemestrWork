CREATE FUNCTION add_vendor (ulogin character varying, upassword character varying, ufirst_name character varying, ulast_name character varying, vphone_number character varying) RETURNS void
	LANGUAGE plpgsql
AS $$
DECLARE
  uid INT;
BEGIN
  INSERT INTO users (login, password, first_name, last_name)
  VALUES (ulogin, upassword, ufirst_name, ulast_name)
  RETURNING user_id INTO uid;
  INSERT INTO vendors (user_id, phone_number)
  VALUES (uid, vphone_number);
END;
$$
