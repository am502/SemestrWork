CREATE VIEW user_customer AS
SELECT u.last_name,
    u.first_name,
    u.user_id,
    c.customer_id,
    c.phone_number,
    c.status
   FROM (users u
     JOIN customers c ON ((c.user_id = u.user_id)))