CREATE VIEW user_vendor AS
SELECT u.last_name,
    u.first_name,
    u.user_id,
    v.vendor_id,
    v.phone_number,
    v.status
   FROM (users u
     JOIN vendors v ON ((v.user_id = u.user_id)))